const getAllInscriptosTit = require('./getAllInscriptosTit.js');
const editInscriptoTit = require('./editInscriptoTit.js');
const updestadoinscriptotit = require('./updestadoinscriptotit.js');
const getReporteEstadoInscriptosTit = require('./getReporteEstadoInscriptosTit.js');


module.exports={
    getAllInscriptosTit,
    editInscriptoTit,
    updestadoinscriptotit,
    getReporteEstadoInscriptosTit
}